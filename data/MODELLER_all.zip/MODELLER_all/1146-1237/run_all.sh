nohup python all_sjkim_final.py &

zip models.zip *.B999900*.pdb
rm -rf *.D*
rm -rf *.V*
rm -rf *.ini
rm -rf *.rsr
rm -rf *.sch

