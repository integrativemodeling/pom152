nohup ./lyre_1_job_clustering_precision_rmsf.sh &

