cp -pr chimera.py kmeans_500_1/cluster.0/

cp -pr chimera.py kmeans_500_2/cluster.0/
cp -pr chimera.py kmeans_500_2/cluster.1/

cp -pr chimera.py kmeans_500_3/cluster.0/
cp -pr chimera.py kmeans_500_3/cluster.1/
cp -pr chimera.py kmeans_500_3/cluster.2/

cp -pr chimera.py kmeans_500_4/cluster.0/
cp -pr chimera.py kmeans_500_4/cluster.1/
cp -pr chimera.py kmeans_500_4/cluster.2/
cp -pr chimera.py kmeans_500_4/cluster.3/

cp -pr chimera.py kmeans_500_5/cluster.0/
cp -pr chimera.py kmeans_500_5/cluster.1/
cp -pr chimera.py kmeans_500_5/cluster.2/
cp -pr chimera.py kmeans_500_5/cluster.3/
cp -pr chimera.py kmeans_500_5/cluster.4/

cp -pr chimera.py kmeans_500_6/cluster.0/
cp -pr chimera.py kmeans_500_6/cluster.1/
cp -pr chimera.py kmeans_500_6/cluster.2/
cp -pr chimera.py kmeans_500_6/cluster.3/
cp -pr chimera.py kmeans_500_6/cluster.4/
cp -pr chimera.py kmeans_500_6/cluster.5/

