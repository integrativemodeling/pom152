PWD_PARENT=$(pwd)

#for DIR_SA in modeling_*
#do
#    cd $DIR_SA
: '
    for DIR in modeling*; do
        if [ -d "$DIR" ]; then
            echo "tar czf $DIR.tar.gz $DIR"
            tar czf $DIR.tar.gz $DIR
            rm -rf $DIR
        fi
    done
    #exit -1
' 
    for DIR in "kmeans_500_3" "kmeans_500_4" "kmeans_500_5" "kmeans_500_6"; do
        if [ -d "$DIR" ]; then
            echo "tar czf $DIR.tar.gz $DIR"
            tar czf $DIR.tar.gz $DIR
            rm -rf $DIR
        fi
    done


#    cd ..
#done

